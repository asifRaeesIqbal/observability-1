dependencies {
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.11.3")
    implementation("org.springframework.boot:spring-boot-starter")
}
